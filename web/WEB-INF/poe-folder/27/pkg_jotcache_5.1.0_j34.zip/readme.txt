README for JotCache ver.5.1.0 for Joomla 3.4

copyright (C) 2010-2015 Vladimir Kanich
license GNU General Public License version 2 or later

Introduction
------------
JotCache is advanced solution for page caching in Joomla CMS ver. 1.5 / 2.5 / 3.x JotCache is replacement of standard System-Cache plugin with following enhancements :

- Easy management of page caching with possibility to set different options for caching : browser types, caching inclusion/exclusion of selected pages, autoclean of expired cached pages(different modes), marking cached items for flexible administration.

- JotCache Management allows to see the actual cached pages linked to related component and component view. Here is possibility to delete only  selected cached pages (marked in component list view) leaving the rest of cached pages intact.

- Fast overview of caching and page recaching on front-end pages. Site administrators can mark their browser access with specific cookie allowing to display/recache marked content (in front-end) solely to these privileged users.

- With URL caching rules is possible to select which components, their specific views or selected pages based on URL query parameters will be included/excluded from page caching. It is possible also to exclude selected template positions from caching to allow proper refresh of modules with dynamic content.

- JotCache supports browser caching for selected groups of pages with not often changed page content. Necessary definitions for pages URI and browser cache expiration time can be set via component management.

Installation
------------
Upload and install the JotCache via Joomla Administrator using pkg_jotcache_..._j33.zip file. During installation are created following parts : JotCache Component, JotCache (system) plugin, JotMarker (system) plugin and three JotCache plugins - Crawler, Crawlerext and Recache.
Set up first your preferencies and settings for JotCache plugin (Plugin manager / JotCache).
Detailed informations about post-installation setup as well as extension uninstallation you can find in JotCache component Help (also available on http://jotcomponents.net/web-programming/jotcache/jotcache-help). 

For uninstallation select in Extension Manager:Manage JotCache package and click on Uninstall toolbar button.

Version history (Joomla 3.x)
---------------
5.1.0 Major release for use with Joomla 3.4
      New features :
      - automatic delete of page edited in frontend from cache. User performing frontend page edit must have at least CREATE user permission (in standard Joomla permission assignment Author group and above)
      - possibility to cache only pages invoked from own site
      - on component Management View is included popup window showing Joomla internal URL string for given page (parts of internal URI can be used for URL Exclusion)
      Changes :
      - jotcache.js used on JotCache component pages is complete rewritten to jQuery
      - memcache cache storage is adjusted to latest PHP Memcache functionality
      - URL exclusion also valid for key/value pair containing %xx (URL coded characters)
5.0.8 Major change in exclusion of template positions (modules) evoked by problems 
      with some templates (Gantry) which re-formats HTML code according to its own rules.
      Implemented are :
      - new jot tags - conform with XHTML 1.0 Strict standard
      - code refactoring in JotMarker plugin for faster processing 
5.0.6 Maintenance release 
      - fixed browser cache warning when db table with definitions is empty
      - fixed problem with memcache, memcached cache storages when message is displayed on frontend page
5.0.5 Maintenance release - fixed bug causing server error during enabled browser caching 
5.0.4 Maintenance release - plugin code refactoring and implemented following changes :
      - check/set of cache file directory permissions during installation
5.0.2 Maintenance release - code refactoring and solved bugs :
      - wrong permission (0341) assigned to /cache/page directory when creating during recache process
      - corrected Cookie Split function
5.0.1 Included new features :
      - Multisite operation
      - Use of memcached (server) as cache storage
      - Extended URL caching rules (include/exclude general mode, using logical AND in rule expressions)
      - Cache Operation Modes (previous Browser Split) with possibility for each browser category (incl. phones, tablets) to select own operation mode - exclude from caching, use common cache (for different browser categories) or use individual cache
4.1.2 - corrected initialisation of template position exclusions
NEW FEATURES (compared to ver.3.1.9) :
4.1.0 - major refactoring of existing features and adding new possibilities for caching/recaching of the site content
      - added and full rewritten JotMarker plugin (compared to ver.4.0.5 / J2.5) for safe module (template position) exclusion
      - manual recache of marked files for users with JotCache recache rights (permission setting necessary). In this working mode authorized user can start on frontend pages the recache of viewed page and see immediatelly the results.
      - batch recache of all or selected pages from Joomla backend with two basic modii :
        a. recaching of existent (already) cached pages (can be processed also oldier expired pages)
        b. web crawling on the site with given depth of levels under site root
      - all recache operations are performed without disturbing of active users on the site. Long batch operations give indication about number of processed pages and it is also possible to stop recaching in any time after the start.
      - batch recache can be also processed as cron job with different setting possibilities
      - strengthened security during cache activities
      - implemented loading of active template language files in plugin (necessary when some modules relies on template language keys)
      - removed feature - compress cached content because of not reliable compression on complex web pages
      - jot tags definitions (needed for module exclusion on template) changed from <!-- jot.... --> string to <jot.... > (no more defined as HTML comment)
      - template module positions needed for 'Position Exclude' management form are no more taken from templateDetails.xml but from frontend module positions which are assigned and enabled in Module Manager
      - cookies split is allowing separate cache storage based on cookie name/value (and related module exclusion)
      - possibility to exclude bots (crawlers) requests from caching (can be also helpfull when on site are different frontend presentations for users and bots)
      - method 'remove expired items' is moved from management view opening to view Refresh (necessary for large sites to start work immediatelly with management functions)
      - possibility to present HTML content of each cached page for JotCache adjustment purposes (debug) with configuration parameter 'Show file hash' enabled
      - implemented loading of lib_joomla language files in plugin
      - possibility of fast delete of selected cached pages without any further confirmation
---------------
3.1.9 - corrected bug in template position exclusions (wrong recognized links with absolute URL)
3.1.8 - enhanced template position exclusions
3.1.7 - solved problem with error in Joomla 3.2 'Call to a member function getTag() on a non-object'
3.1.5 - adjustment of coding for Joomla 3.2
3.1.4 - maintenance version with strengthened security during cache activities
3.1.3 - compress cached content code was rewritten to improve correct compression when HTML tag or javascript code spans over more as one line of code
3.1.2 - added recognition of mobile devices for browser split function (each browser group can have own cached pages based on plugin setting)
      - corrected page caching in case when page title contains special characters (as ' etc.)
      - adjusted layout of component administrator pages to Joomla 3.0 Bootstrap

3.0.2 - first Joomla 3.0 JotCache extension with new features (against versions 2.x) included :
      - template positions exclusion from caching processing with dedicated form in JotCache component management
      - possibility to select site URL requests which will force browser caching (locally on user side)
      - rewritten database access for using different database systems
      - added listing and filtering of cached pages based on page URI
      - removing jot tags markers from server response (they are still presented only for administrator during active Mark operation)

More information is included in JotCache Help http://www.jotcomponents.net/web-programming/jotcache/jotcache-help